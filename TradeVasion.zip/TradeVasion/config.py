# 🎼 توکن ربات تلگرام
TELEGRAM_BOT_TOKEN = "7430379055:AAFoP1PGEZZIM1HzemjNZJghHQPA6l12i94"

# 🎼 تنظیم API Binance
BINANCE_API_KEY = "nMwME9MS5Bl8Bd070e49OKVTIKCbjHzYYwDMvxteF26nuuy2XII04XFJnawzLFat"
BINANCE_API_SECRET = "nbZ1its4h7Jt96CMeI9qsxh6WOFdxnqYftLMVSExpMzFyZ8akoDIz3uootonWXwN"

# 🎼 لینک‌های ضروری
YOUTUBE_CHANNEL = "https://youtube.com/@politikarrr?si=L8qVFFtfoYBU50NX"
TELEGRAM_CHANNEL = "https://t.me/AFSalehi"

# 🎼 اطلاعات پشتیبانی
SUPPORT_TELEGRAM = "hasibmuradi"
SUPPORT_EMAIL = "hasib.muradih01@gmail.com"
