import telegram_bot  # راه‌اندازی ربات تلگرام

if __name__ == "__main__":
    print("✅ Bot is running...")
    telegram_bot.run_bot()
